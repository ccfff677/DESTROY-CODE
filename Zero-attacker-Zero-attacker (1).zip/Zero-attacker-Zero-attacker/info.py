import sys,os
from colorama import Fore
print(Fore.MAGENTA+"""

Zero Attacker is bunch of tools which we made for people.These all tools are for purpose of ethical hacking and discord tools.


""")
print(Fore.RED+"""Getting Started

git clone https://github.com/AsjadOwO/Zero-attacker.git
cd Zero-Attacker
python -m pip install -r requirements.txt
for(Windows user just run the bat file (start.bat) )
Run Python zero.py


License
Zero-Tool is under the MIT License
Using it without giving us credit would lead to Breaking the License law


""")