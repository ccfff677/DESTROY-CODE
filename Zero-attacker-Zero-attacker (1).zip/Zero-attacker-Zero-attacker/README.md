### Zero Attacker
 
- 2.0 VERSION IS HERE 

- Zero Attacker is bunch of tools which we made for people.These all tools are for purpose of ethical hacking and discord tools.

- Re-Lauch of the tool this time with the source code (remember this is completely basic of the tool for buying additional tools with advance version you can reach out to us on discord, we provide all type of stuff)

- 📣 Website is launching soon https://zerooffenssecurity.cloud/ 




### Paid Tools 
We are also providing advance paid tools to help you with in different penteration testing, etc (Join the server to know more about it)- [ server](https://discord.gg/J5X3KnBPGe)


### Getting Started
-  git clone https://github.com/AsjadOooO/Zero-attacker/
- `cd Zero-Attacker`
- `python -m pip install -r requirements.txt`
- for(Windows user just run the bat file (`install.bat` if running first time else `start.bat`) )
- run python zero.py


### License

- Zero-Tool  is under the MIT License
- Using it without giving us credit would lead to Breaking the License law

### Preview
![image](https://github.com/AsjadOooO/Zero-attacker/blob/Zero-attacker/1.jpg)
![image](https://github.com/AsjadOooO/Zero-attacker/blob/Zero-attacker/2.jpg)



### Developer 
- Zero Offens Security is owned by Asjad and dev7knight
- Developer are dev7knight,asjad,visa2code 
- Contact for any kind of help  Asjad#0060 (.asjad) or dev7knight 
- [support server](https://discord.gg/J5X3KnBPGe)


[Asjad Personal Site](https://www.asjad.xyz/) <br>
[dev7knight Personal discord server](https://discord.gg/ft7Q8y5UT3) <br> 
[Web-Bugger](https://github.com/dev7knight/WebBugger) <br> 
[visa2code aka Tejas Lamba](https://github.com/TejasLamba2006) <br>


- Zero Tool

<p align="left"> <img src="https://komarev.com/ghpvc/?username=AsjasOooO&label=Profile%20views&color=0e75b6&style=flat" alt="Zero-attacker" /> </p> 



